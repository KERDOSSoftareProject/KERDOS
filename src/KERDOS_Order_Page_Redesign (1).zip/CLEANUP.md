# KERDOS canonical cleanup

This version consolidates the latest uploaded KERDOS source rather than layering another patch.

## Corrected
- One authoritative auto-link cutoff: `MATCH_POLICY.autoLink` (0.85). The old 0.50 catalog-reuse path is removed.
- Organization `industry` is descriptive metadata only. It no longer auto-loads categories or changes engine behavior.
- Optional domain vocabulary is explicit through `knowledgePacks.js`; Restaurant / Food Service v1 is the first pack.
- XLSX, PDF.js, and OCR are package dependencies. No document parser is fetched from a CDN at runtime. OCR is lazy-loaded as a bundled chunk.
- Backend credentials are deployment configuration, not hard-coded in application source.
- `App.jsx` uses the generic `data` and `fileStore` contracts rather than Supabase naming/storage calls.
- Backend selection supports cloud (`supabase`) and on-device (`local`) operation. Local business rows use browser storage and original files use IndexedDB.
- Session policy remains centralized in `session.js`.
- Regression tests consume the central matching policy instead of repeating 0.85.
- Architecture regression tests guard against reintroducing the old 0.50 path, industry templates, runtime CDNs, direct storage coupling, and hard-coded project URLs.

## Deployment
The included `.env` preserves the current cloud deployment configuration so this package continues to point at the same backend when uploaded. `.env.example` documents how to point another deployment elsewhere or select local mode.

## Verification
- Procurement regression suite: 30 passed, 0 failed.
- Session policy tests: passed.
- Local-data adapter tests: passed.
- Architecture tests: passed.
- Node syntax checks passed for non-JSX modules.
- A complete Vite production build could not be verified in this execution environment because dependency installation timed out. Do not treat this note as a successful production build.
