import fs from "fs";
const app=fs.readFileSync("./App.jsx","utf8");
const data=fs.readFileSync("./data.js","utf8");
const procurement=fs.readFileSync("./procurement.js","utf8");
const checks=[
 ["no 50% auto-link path", !/bestScore\s*>=\s*0\.5/.test(app)],
 ["no industry_templates behavior", !/industry_templates|loadStarterCategoriesForIndustry|loadIndustryTemplates/.test(app)],
 ["no runtime CDN", !/cdnjs|loadScript\(|window\.Tesseract/.test(app)],
 ["App uses generic data name", !/\bsupabase\b/i.test(app)],
 ["App does not reach into backend storage", !/\.storage\.from\(/.test(app)],
 ["no hard-coded Supabase project URL", !/supabase\.co/.test(data)],
 ["central match policy used", /MATCH_POLICY\.autoLink/.test(app) && /MATCH_POLICY/.test(procurement)],
 ["industry absent from procurement engine", !/INDUSTRY_PRESETS|industry_templates|orgIndustry/.test(procurement)],
];
let failed=0; for(const [name,ok] of checks){ console.log(`${ok?"PASS":"FAIL"}  ${name}`); if(!ok) failed++; }
if(failed) process.exit(1);
