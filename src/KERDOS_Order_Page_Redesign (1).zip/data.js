// KERDOS backend adapter. This is the only module that selects a backend.
// The application can run cloud-backed or entirely on-device without changing UI code.
import { createClient } from "@supabase/supabase-js";
import { createSessionController } from "./session.js";
import { localData } from "./localData.js";

const requestedBackend = (import.meta.env?.VITE_DATA_BACKEND || "supabase").toLowerCase();
const SUPABASE_URL = import.meta.env?.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env?.VITE_SUPABASE_ANON_KEY;

function makeCloudData(){
  if(!SUPABASE_URL || !SUPABASE_ANON_KEY){
    throw new Error("KERDOS cloud backend is not configured. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY, or set VITE_DATA_BACKEND=local.");
  }
  return createClient(SUPABASE_URL,SUPABASE_ANON_KEY);
}

export const data = requestedBackend === "local" ? localData : makeCloudData();
export const sessionController = createSessionController(data.auth);
const documents = data.storage.from("documents");
export const fileStore = Object.freeze({
  upload: (path,file,options) => documents.upload(path,file,options),
  createSignedUrl: (path,expiresIn=3600) => documents.createSignedUrl(path,expiresIn),
  remove: paths => documents.remove(paths),
});
export const backendInfo = Object.freeze({
  kind: requestedBackend === "local" ? "local" : "supabase",
  url: requestedBackend === "local" ? null : SUPABASE_URL,
  configured: requestedBackend === "local" || Boolean(SUPABASE_URL && SUPABASE_ANON_KEY),
});
