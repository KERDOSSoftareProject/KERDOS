// KERDOS local-first persistence adapter.
// Implements the small Supabase-shaped API the current UI uses, but stores
// business data in this browser. No network, account, vendor API, or cloud
// service is required for the core procurement workflow.

const DB_KEY = "kerdos.local.db.v1";
const SESSION_KEY = "kerdos.local.session.v1";
const listeners = new Set();

const emptyDb = () => ({
  profiles: [], organizations: [], organization_members: [], vendors: [],
  catalog_categories: [], catalog_items: [], vendor_items: [], item_mappings: [],
  invoices: [], invoice_lines: [], purchase_orders: [], purchase_order_lines: [],
  price_history: [], invite_codes: [], local_users: []
});

function readDb() {
  try { return { ...emptyDb(), ...(JSON.parse(localStorage.getItem(DB_KEY)) || {}) }; }
  catch { return emptyDb(); }
}
function writeDb(db) { localStorage.setItem(DB_KEY, JSON.stringify(db)); listeners.forEach(fn => fn()); }
function id() { return crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`; }
function clone(v) { return v == null ? v : JSON.parse(JSON.stringify(v)); }
function now() { return new Date().toISOString(); }

async function digest(text) {
  if (!crypto?.subtle) return `local:${text}`;
  const bytes = new TextEncoder().encode(text);
  const hash = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(hash)].map(b => b.toString(16).padStart(2,"0")).join("");
}

function currentSession() {
  try { return JSON.parse(localStorage.getItem(SESSION_KEY)) || null; } catch { return null; }
}
function setSession(session, event) {
  if (session) localStorage.setItem(SESSION_KEY, JSON.stringify(session)); else localStorage.removeItem(SESSION_KEY);
  authListeners.forEach(fn => fn(event, clone(session)));
}
const authListeners = new Set();

class Query {
  constructor(table, action="select", payload=null) {
    this.table=table; this.action=action; this.payload=payload; this.filters=[];
    this.orders=[]; this.max=null; this.wantSingle=false; this.wantMaybe=false;
  }
  select(){ return this; }
  eq(k,v){ this.filters.push(r => r?.[k] === v); return this; }
  is(k,v){ this.filters.push(r => r?.[k] === v || (v===null && r?.[k] == null)); return this; }
  ilike(k,v){ const needle=String(v??"").replaceAll("%","").toLowerCase(); this.filters.push(r => String(r?.[k]??"").toLowerCase().includes(needle)); return this; }
  in(k,vals){ const s=new Set(vals||[]); this.filters.push(r=>s.has(r?.[k])); return this; }
  order(k,opts={}){ this.orders.push([k,opts]); return this; }
  limit(n){ this.max=n; return this; }
  single(){ this.wantSingle=true; return this; }
  maybeSingle(){ this.wantMaybe=true; return this; }
  then(resolve,reject){ return this.execute().then(resolve,reject); }
  matches(r){ return this.filters.every(fn=>fn(r)); }
  enrich(rows, db){
    return rows.map(row=>{
      const r={...row};
      if(this.table==="organization_members") r.organizations=db.organizations.find(x=>x.id===r.organization_id)||null;
      if(this.table==="catalog_items") r.catalog_categories=db.catalog_categories.find(x=>x.id===r.category_id) ? {name:db.catalog_categories.find(x=>x.id===r.category_id).name}:null;
      if(this.table==="invoices") { const v=db.vendors.find(x=>x.id===r.vendor_id); r.vendors=v?{name:v.name}:null; r.invoice_lines=db.invoice_lines.filter(x=>x.invoice_id===r.id); }
      if(this.table==="purchase_orders") r.purchase_order_lines=db.purchase_order_lines.filter(x=>x.purchase_order_id===r.id);
      return r;
    });
  }
  async execute(){
    const db=readDb(); if(!db[this.table]) db[this.table]=[];
    let data=null, error=null;
    try {
      if(this.action==="select") {
        let rows=db[this.table].filter(r=>this.matches(r));
        for(const [k,o] of this.orders.slice().reverse()) rows.sort((a,b)=>{ const av=a?.[k], bv=b?.[k]; if(av==null&&bv==null)return 0;if(av==null)return o.nullsFirst?-1:1;if(bv==null)return o.nullsFirst?1:-1; const c=String(av).localeCompare(String(bv),undefined,{numeric:true}); return o.ascending===false?-c:c; });
        if(this.max!=null) rows=rows.slice(0,this.max);
        rows=this.enrich(rows,db); data=clone(rows);
      } else if(this.action==="insert") {
        const input=Array.isArray(this.payload)?this.payload:[this.payload];
        const created=input.map(x=>({id:x.id||id(),created_at:x.created_at||now(),...clone(x)}));
        db[this.table].push(...created); writeDb(db); data=created;
      } else if(this.action==="upsert") {
        const input=Array.isArray(this.payload)?this.payload:[this.payload]; const out=[];
        for(const x of input){ let i=x.id?db[this.table].findIndex(r=>r.id===x.id):-1; if(i>=0){db[this.table][i]={...db[this.table][i],...clone(x)};out.push(db[this.table][i]);}else{const c={id:x.id||id(),created_at:x.created_at||now(),...clone(x)};db[this.table].push(c);out.push(c);} }
        writeDb(db); data=out;
      } else if(this.action==="update") {
        const out=[]; db[this.table]=db[this.table].map(r=>this.matches(r)?(out.push({...r,...clone(this.payload)}),{...r,...clone(this.payload)}):r); writeDb(db); data=out;
      } else if(this.action==="delete") {
        const removed=db[this.table].filter(r=>this.matches(r)); db[this.table]=db[this.table].filter(r=>!this.matches(r)); writeDb(db); data=removed;
      }
      if(this.wantSingle){ if(!data?.length) throw new Error("No matching row"); data=data[0]; }
      else if(this.wantMaybe) data=data?.[0]||null;
    } catch(e){ error={message:e.message||String(e)}; data=null; }
    return {data,error};
  }
}

function from(table){ return { select:()=>new Query(table,"select"), insert:p=>new Query(table,"insert",p), upsert:p=>new Query(table,"upsert",p), update:p=>new Query(table,"update",p), delete:()=>new Query(table,"delete") }; }

// Original source files are kept in IndexedDB because localStorage is not safe
// for large PDFs/spreadsheets. Business rows remain simple JSON for portability.
const FILE_DB="kerdos.local.files.v1", FILE_STORE="files";
function openFileDb(){ return new Promise((resolve,reject)=>{ const req=indexedDB.open(FILE_DB,1); req.onupgradeneeded=()=>req.result.createObjectStore(FILE_STORE); req.onsuccess=()=>resolve(req.result); req.onerror=()=>reject(req.error); }); }
async function putFile(path,file){ const db=await openFileDb(); await new Promise((resolve,reject)=>{const tx=db.transaction(FILE_STORE,"readwrite");tx.objectStore(FILE_STORE).put(file,path);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);}); db.close(); }
async function deleteFiles(paths){ const db=await openFileDb(); await new Promise((resolve,reject)=>{const tx=db.transaction(FILE_STORE,"readwrite");const store=tx.objectStore(FILE_STORE);for(const path of paths||[]) store.delete(path);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});db.close();}
async function getFile(path){ const db=await openFileDb(); const file=await new Promise((resolve,reject)=>{const tx=db.transaction(FILE_STORE,"readonly");const req=tx.objectStore(FILE_STORE).get(path);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});db.close();return file; }

export const localData = {
  from,
  auth:{
    async getSession(){ return {data:{session:currentSession()}}; },
    onAuthStateChange(fn){ authListeners.add(fn); return {data:{subscription:{unsubscribe:()=>authListeners.delete(fn)}}}; },
    async signUp({email,password}){ const db=readDb(); const key=String(email).trim().toLowerCase(); if(db.local_users.some(u=>u.email===key)) return {data:null,error:{message:"A local account with that email already exists."}}; const user={id:id(),email:key,password_hash:await digest(password),created_at:now()}; db.local_users.push(user); writeDb(db); const session={user:{id:user.id,email:user.email}}; setSession(session,"SIGNED_IN"); return {data:{user:session.user,session},error:null}; },
    async signInWithPassword({email,password}){ const db=readDb(); const key=String(email).trim().toLowerCase(); const user=db.local_users.find(u=>u.email===key); if(!user || user.password_hash!==await digest(password)) return {data:null,error:{message:"Incorrect local email or password."}}; const session={user:{id:user.id,email:user.email}}; setSession(session,"SIGNED_IN"); return {data:{user:session.user,session},error:null}; },
    async signOut(){ setSession(null,"SIGNED_OUT"); return {error:null}; }
  },
  storage:{ from(){ return { async upload(path,file){ try{await putFile(path,file);return {data:{path},error:null};}catch(e){return {data:null,error:{message:e.message}};} }, async createSignedUrl(path){ try{const file=await getFile(path);if(!file)return {data:null,error:{message:"Local file not found"}};return {data:{signedUrl:URL.createObjectURL(file)},error:null};}catch(e){return {data:null,error:{message:e.message}};} }, async remove(paths){ try{await deleteFiles(paths);return {data:paths,error:null};}catch(e){return {data:null,error:{message:e.message}};} } }; } },
  channel(){ return { on(){return this;}, subscribe(){return this;} }; }, removeChannel(){},
  _export(){ return clone(readDb()); },
  _import(snapshot){ writeDb({...emptyDb(),...clone(snapshot)}); },
  _reset(){ localStorage.removeItem(DB_KEY); localStorage.removeItem(SESSION_KEY); }
};
